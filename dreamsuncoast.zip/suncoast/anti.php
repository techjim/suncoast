<?php


require 'prevents/bt.php';
require 'prevents/antibot.php';

?>